#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Thu Aug 22 09:10:13 2019

@author: davidblair
"""

name = "vlpi.model"
